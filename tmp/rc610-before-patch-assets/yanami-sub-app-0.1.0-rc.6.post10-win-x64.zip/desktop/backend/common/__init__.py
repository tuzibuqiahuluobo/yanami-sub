"""Shared desktop backend contracts."""
