"""Managed worker process lifecycle."""
