"""Yanami Sub pywebview launcher."""
