"""Local desktop settings storage."""
