"""Isolated FineSub pipeline worker."""
