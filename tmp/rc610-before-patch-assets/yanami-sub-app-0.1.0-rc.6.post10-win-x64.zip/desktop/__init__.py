"""Yanami Sub application package."""
