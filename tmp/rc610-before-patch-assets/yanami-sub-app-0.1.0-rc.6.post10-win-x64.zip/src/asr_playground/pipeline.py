"""Compatibility placeholder for pre-0.4.0 launchers.

The package was renamed to ``finesub`` in 0.4.0. Launchers frozen before the
rename validate update payloads and locate the active application source by
checking that this file exists; they never import it. See
desktop/scripts/package-bootstrap.ps1 for why it is generated here.
"""

raise ImportError(
    "asr_playground was renamed to finesub in 0.4.0; "
    "this stub only satisfies pre-0.4.0 launchers' payload checks"
)
